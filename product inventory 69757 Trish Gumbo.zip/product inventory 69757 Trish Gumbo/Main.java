import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    Scanner scanner = new Scanner(System.in);
    ArrayList<Product> inventory = new ArrayList<>();

    public static void main(String[] args) {
        Main app = new Main();
        app.run();
    }

    public void run() {
        boolean finish = false;

        while (!finish) {
            System.out.println("1. Add product");
            System.out.println("2. View  the products");
            System.out.println("3. Update Product Quantity");
            System.out.println(" 4.Search for product");
            System.out.println("Exit");

            System.out.println("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    viewAllProducts();
                    break;
                case 3:
                    updateProductQuantity();
                    break;
                case 4:
                    searchProduct();
                    break;
                case 5:
                    finish = true;
                    System.out.println(" finishing program");
                    break;
                default:
                    System.out.println("invalid options");
            }
        }

    }

    public void addProduct() {

        System.out.println(" Name of product : ");
        String name = scanner.nextLine();
        System.out.println(" Price of product : ");
        double price = scanner.nextDouble();
        System.out.println(" Quantity of product : ");
        int quantity = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter product type (Electronics/Groceries): ");
        String type = scanner.nextLine();

        if (type.equalsIgnoreCase("Electronics")) {
            System.out.print("Enter warranty period: ");
            String warrantyPeriod = scanner.nextLine();
            inventory.add(new Electronics(name, price, quantity, warrantyPeriod));
        } else if (type.equalsIgnoreCase("Groceries")) {
            System.out.print("Enter expiration date: ");
            String expirationDate = scanner.nextLine();
            inventory.add(new Groceries(name, price, quantity, expirationDate));
        } else {
            System.out.println("Invalid product type.");
        }
    }

    public void viewAllProducts() {
        if (inventory.isEmpty()) {
            System.out.println("Empty inventory");
        } else {
            System.out.println(" ------All products in store -----");
            for (Product product : inventory) {
                System.out.println(product);
            }
        }
    }

    public void updateProductQuantity() {
        System.out.println("Enter the product name to update quantity: ");
        String name = scanner.nextLine();
        Product product = findProductByName(name);

        if (product != null) {
            System.out.print("Enter new quantity: ");
            int newQuantity = scanner.nextInt();
            scanner.nextLine();
            product.pQuantity(newQuantity);
            System.out.println("Quantity updated successfully.");
        } else {
            System.out.println("Product not found.");
        }
    }

    private void searchProduct() {
        System.out.print("Enter the product name to search: ");
        String name = scanner.nextLine();
        Product product = findProductByName(name);

        if (product != null) {
            System.out.println("\n--- Product Details ---");
            System.out.println(product);
        } else {
            System.out.println("Product not found.");
        }

    }

    public Product findProductByName (String  name){
        for (Product product : inventory) {
            if (product.pName().equalsIgnoreCase(name)) {
                return product;
            }
        }
        return null;
    }
}