 class Groceries extends Product {

    String expirationDate;

    public Groceries( String name, double price , int quantity, String expirationDate){
        super(name, price , quantity);
        this.expirationDate = expirationDate;

    }
    @Override
     public double calculateTotalValue(){
        return price * quantity;
     }

     @Override
     public String toString(){

        return super.toString() + ", Expiration Date: " + expirationDate ;
     }

}
