abstract class Product {
    String name;
    double price;
    int quantity;

   public Product(String name, double price , int quantity){

        this.name = name;
        this.price = price;
        this.quantity = quantity;


    }
  public abstract double calculateTotalValue();

    public  String pName(){
        return name;
    }
   public  void pQuantity(int quantity){
        this.quantity = quantity;
    }

    @Override
    public String toString(){
        return "Name: " + name + "Price: $" + price + ", Quantity: " + quantity ;
    }
}
