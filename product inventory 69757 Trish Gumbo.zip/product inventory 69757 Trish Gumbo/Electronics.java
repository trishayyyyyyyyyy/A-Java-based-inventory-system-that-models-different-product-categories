

class Electronics extends Product {

    String warrantyPeriod;

    public Electronics( String name, double price, int quantity, String warrantyPeriod){
        super(name ,price, quantity);
        this.warrantyPeriod = warrantyPeriod;
    }

    @Override
    public double calculateTotalValue(){
        return price * quantity;
    }
 @Override
    public String toString(){
        return super.toString() +", Warrant period: " + warrantyPeriod ;
 }
}
